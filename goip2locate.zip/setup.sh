#!/bin/sh
#
echo "create bin director."
ROOT=/usr/local/goip2locate
mkdir $ROOT
#
echo "coping resource files."
cp -f ./init.d/goip2locate /etc/init.d/goip2locate
cp -rf ./app/* $ROOT
cp -rf ./data/* $ROOT
#
echo "adding goip2locate to system service."
chkconfig --add goip2locate
echo `chkconfig --list |grep goip2locate`



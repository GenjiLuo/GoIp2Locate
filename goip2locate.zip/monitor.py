import os
import time
import logging

log_filename = "/home/servicemonitor/goIp2Locate/check_status.log"
start_script   = "/etc/init.d/goIp2Locate restart"
get_pid_cmd  = "ps -ef |grep -w goIp2Locate |grep -v grep |awk '{print$2}'"
logger = logging.getLogger('goIp2LocateChecker')
logger.setLevel(logging.INFO) # DEBUG | INFO | WARNING | ERROR | CRITICAL
fh = logging.FileHandler(log_filename, encoding='utf-8')
formatter = logging.Formatter(
    fmt="%(asctime)s %(name)s %(filename)s %(message)s",
    datefmt="%Y/%m/%d %X")
fh.setFormatter(formatter)
logger.addHandler(fh)

def get_process_pid():
    res = os.popen(get_pid_cmd).readlines()
    if res and len(res) > 0:
        return res[-1].strip()
    return None

def run():
    try:
        nlp_pid = get_process_pid()
        if nlp_pid == None:
            os.popen(start_script)
            nlp_pid = get_process_pid()
            logger.info("restart goIp2Locate process: %s", nlp_pid)
    except:
        logger.error("restart goIp2Locate faild.")

    nlp_pid = get_process_pid()
    if nlp_pid == None:
        logger.error("restart goIp2Locate faild.")

if __name__ == '__main__':
    logger.info("#####START GoIp2Locate SERVICE CHECKER#####")
    while True:
        run()
        time.sleep(3)
